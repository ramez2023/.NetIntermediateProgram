using WEBAPI.Common.ViewModels;

namespace WEBAPI.Service.ViewModels
{
    public class AddCategoryRequestVm : BaseRequestVm
    {
        public string Name { get; set; }
    }
}
