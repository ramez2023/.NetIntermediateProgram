﻿namespace WEBAPI.Common.Exceptions.Business
{
    public class ForbiddenException : BaseException
    {

    }
}
