﻿namespace WEBAPI.Common.Exceptions.Business
{
    public abstract class BusinessException : BaseException
    {

    }
}