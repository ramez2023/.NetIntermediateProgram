using System;
using System.Collections.Generic;
using System.Text;

namespace WEBAPI.Common.Enums
{
    public enum ProductSortAttributes
    {
        CreateDate,
        Id,
        Name,
        Price,
        Sku
    }
}

