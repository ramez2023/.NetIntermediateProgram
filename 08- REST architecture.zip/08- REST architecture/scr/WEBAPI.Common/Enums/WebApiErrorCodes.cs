﻿namespace WEBAPI.Common.Enums
{
    /// <summary>
    /// From 100
    /// </summary>
    public enum WebApiErrorCodes
    {
        CategoryNotFound = 1000,
        ProductNotFound = 1001,
    }
}