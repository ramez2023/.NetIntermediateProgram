using System;
using System.Collections.Generic;
using System.Text;

namespace WEBAPI.Common.Enums
{
    public enum CategorySortAttributes
    {
        CreateDate,
        Id,
        Name,
    }
}

