﻿namespace WEBAPI.Common.Enums
{
    public enum SortDirection
    {
        Desc = 0,
        Asc = 1
    }
}
