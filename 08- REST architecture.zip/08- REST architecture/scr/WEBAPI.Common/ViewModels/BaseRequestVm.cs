﻿using WEBAPI.Common.Enums;
using Microsoft.AspNetCore.Mvc;

namespace WEBAPI.Common.ViewModels
{
    public class BaseRequestVm
    {

    }
}
