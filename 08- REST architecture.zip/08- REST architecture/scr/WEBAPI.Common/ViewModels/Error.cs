﻿namespace WEBAPI.Common.ViewModels
{
    public class Error
    {
        public string ErrorMessage { get; set; }
    }
}
