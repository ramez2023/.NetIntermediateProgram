﻿namespace WEBAPI.Common.ViewModels
{
    public class PaginationModel
    {
        public bool IsPaging { get; set; }
        public int PageNumber { get; set; }
        public int PageElementsCount { get; set; }
    }
}
